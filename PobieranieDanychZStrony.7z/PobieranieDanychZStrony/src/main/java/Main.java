import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Document doc = null;
        try{
            doc = Jsoup.connect("https://eune.op.gg/champion/statistics").get();
        } catch (IOException e){
            e.printStackTrace();
        }

        Element elementy = doc.getAllElements().first();
        String postacie = elementy.getElementsByClass("champion-index-table__name").text();
        String procenty = elementy.getElementsByClass("champion-index-table__cell champion-index-table__cell--value").text();
        String[] tablicaPostaci = postacie.split(" ");
        String[] tablicaProcenty1 = procenty.split(" ");

        PrintWriter wynik = new PrintWriter("postacie.txt");

        wynik.println("[Bohater, Pick Rate, Win Rate]");
        for(int i=0; i<20; i++) {
            wynik.println(i+1 + ". " + tablicaPostaci[i] + "   " + tablicaProcenty1[i*3+1] + "   " + tablicaProcenty1[i*3]);
        }

        wynik.close();

    }
}